# Evaluation module for ScholarRAG

